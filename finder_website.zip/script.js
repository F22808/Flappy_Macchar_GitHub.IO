function search() {
  const query = document.getElementById("searchInput").value.trim();
  if (query === "") {
    alert("Please enter something to search.");
  } else {
    window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
  }
}
