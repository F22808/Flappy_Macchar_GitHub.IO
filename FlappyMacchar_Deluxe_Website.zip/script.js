let canvas = document.getElementById("gameCanvas");
let ctx = canvas.getContext("2d");
canvas.width = 320;
canvas.height = 480;

let mosquito = new Image();
mosquito.src = "assets/images/mosquito.png";

let mosquitoY = 150;
let gravity = 1.5;
let velocity = 0;
let score = 0;
let isGameRunning = false;

function drawMosquito() {
    ctx.drawImage(mosquito, 50, mosquitoY, 50, 50);
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawMosquito();
    velocity += gravity;
    mosquitoY += velocity;

    if (mosquitoY + 50 > canvas.height) {
        endGame();
    }

    document.getElementById("score").innerText = "स्कोर: " + score;

    if (isGameRunning) {
        requestAnimationFrame(update);
    }
}

function startGame() {
    mosquitoY = 150;
    velocity = 0;
    score = 0;
    isGameRunning = true;
    update();
    canvas.onclick = () => jump();
}

function jump() {
    if (isGameRunning) {
        velocity = -12;
        score++;
    }
}

function endGame() {
    isGameRunning = false;
    alert("खेल खत्म! आपका स्कोर: " + score);
}
