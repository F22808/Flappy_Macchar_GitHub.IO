
let canvas = document.getElementById("gameCanvas");
let ctx = canvas.getContext("2d");
canvas.width = 320;
canvas.height = 480;

let mosquito = new Image();
mosquito.src = "assets/images/mosquito.png";

let pipeNorth = new Image();
let pipeSouth = new Image();
pipeNorth.src = "assets/images/pipeNorth.png";
pipeSouth.src = "assets/images/pipeSouth.png";

let mosquitoY = 150;
let gravity = 0.6;
let velocity = 0;
let score = 0;
let isGameRunning = false;

let pipe = {
    x: canvas.width,
    y: Math.floor(Math.random() * -150)
};

function drawMosquito() {
    ctx.drawImage(mosquito, 50, mosquitoY, 40, 40);
}

function drawPipes() {
    ctx.drawImage(pipeNorth, pipe.x, pipe.y);
    ctx.drawImage(pipeSouth, pipe.x, pipe.y + pipeNorth.height + 100);
    pipe.x--;

    if (pipe.x === 50) {
        score++;
        pipe = {
            x: canvas.width,
            y: Math.floor(Math.random() * -150)
        };
    }

    // Collision detection
    if (
        50 + 40 > pipe.x && 50 < pipe.x + pipeNorth.width &&
        (mosquitoY < pipe.y + pipeNorth.height || mosquitoY + 40 > pipe.y + pipeNorth.height + 100)
    ) {
        endGame();
    }
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawMosquito();
    drawPipes();
    velocity += gravity;
    mosquitoY += velocity;

    if (mosquitoY + 40 > canvas.height) {
        endGame();
    }

    document.getElementById("score").innerText = "स्कोर: " + score;

    if (isGameRunning) {
        requestAnimationFrame(update);
    }
}

function startGame() {
    mosquitoY = 150;
    velocity = 0;
    score = 0;
    isGameRunning = true;
    pipe = { x: canvas.width, y: Math.floor(Math.random() * -150) };
    update();
    canvas.onclick = () => jump();
}

function jump() {
    if (isGameRunning) {
        velocity = -10;
    }
}

function endGame() {
    isGameRunning = false;
    alert("खेल खत्म! आपका स्कोर: " + score);
}
