const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let maccharY = 150;
let gravity = 0.6;
let lift = -12;
let velocity = 0;

let pipes = [];
let frame = 0;

document.addEventListener("keydown", () => {
  velocity = lift;
});

function drawMacchar() {
  ctx.fillStyle = "black";
  ctx.beginPath();
  ctx.ellipse(100, maccharY, 15, 10, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawPipe(pipe) {
  ctx.fillStyle = "green";
  ctx.fillRect(pipe.x, 0, pipe.width, pipe.top);
  ctx.fillRect(pipe.x, pipe.bottom, pipe.width, canvas.height - pipe.bottom);
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  velocity += gravity;
  maccharY += velocity;

  if (maccharY > canvas.height) maccharY = canvas.height;
  if (maccharY < 0) maccharY = 0;

  drawMacchar();

  if (frame % 90 === 0) {
    let top = Math.random() * 200 + 50;
    let gap = 120;
    pipes.push({
      x: canvas.width,
      width: 40,
      top: top,
      bottom: top + gap
    });
  }

  pipes.forEach((pipe, index) => {
    pipe.x -= 2;
    drawPipe(pipe);

    // Collision check
    if (
      100 > pipe.x && 100 < pipe.x + pipe.width &&
      (maccharY < pipe.top || maccharY > pipe.bottom)
    ) {
      alert("Macchar takra gaya! Game over.");
      document.location.reload();
    }
  });

  frame++;
  requestAnimationFrame(update);
}

update();
